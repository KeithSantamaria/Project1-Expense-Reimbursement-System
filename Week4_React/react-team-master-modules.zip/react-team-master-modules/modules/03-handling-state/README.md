# Handling State

The purpose of this module is to expand on the [props and state](../02-react-fundamentals/props-and-state.md) topic, giving a more complete understanding of the roles props and state play in a React application.

The topics in this module include:

1. [Immutability](./immutability.md)
2. [One-way Data Flow](./one-way-data-flow.md)
3. [Lifting State](./lifting-state.md)

Before starting with the material in this module, associates should be familiar with the basics of React, including [intro to react](../01-intro-to-react) and [react fundamentals](../02-react-fundamentals).

After completing this module, associates should:

- have an understanding of how state is handled in React, including its immutability and data flow
- be able to lift state as necessary, understanding when to lift state along with some drawbacks that come with the traditional approach of lifting state
