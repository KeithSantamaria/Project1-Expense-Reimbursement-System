# Intro to React Module

The purpose of this module is to introduce the basics of React and give a high level overview regarding what React is, how it is used today, and some of the themes that are prevalent throughout React.

Additional Resources in this module:

- [React Overview](./react-overview.md)
- [Single Page Application](./single-page-application.md)

## List of Topics

- Component-based architecture
- Single Page Applications

## Prerequisites & Learning Objectives

Before starting with the material in this module, associates should be familiar with:

- Front End JavaScript
- TypeScript
- HTML and CSS
- Node and npm

After completing this module, associates should be able to:

- Conceptually understand the purpose of React
- Understand React's approach to building the Client of a web application
- Create a new React application using `create-react-app`
- Explain what a Single Page application is and its benefits
- Create a Single Page Application with React
- Describe what a component is and how React uses components
