## Creating a new React Application

There are many ways of setting up your environment to start writing a UI with React. The simplest and most popular way is to use `create-react-app`:

> npx create-react-app "name-of-react-application"

or if you install create-react-app globally,

> create-react-app "name-of-react-application"

This will generate a new React application that comes preconfigured with dependencies such as: babel, webpack, jest, etc.

Note that this is a shortcut and you could always manually set up your dev environment if you wanted to.

- [create-react-app](https://create-react-app.dev/docs/getting-started)