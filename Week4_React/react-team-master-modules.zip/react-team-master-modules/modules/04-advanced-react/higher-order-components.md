## High Order Components

High order components are functions that take a component and return a new component. The traditional component model transforms props into a portion of the UI. High order components take a component as a parameter and transforms it, returning a new component with added functionality.

High order components can handle cross cutting concerns and allow for even more reusability. [Composition](https://reactjs.org/docs/composition-vs-inheritance.html) is used to wrap a component in a container component.

HOCs add features to a component. Examples can be seen when using [React Router](../02-react-fundamentals/routing.md) and [Redux](../07-redux).

With React Router, you can use the withRouter high-order component to provide your component with additional routing functionality. By passing in your component, you are able to use the history API, through the history object provided as a prop. The HTML history API gives you access to browser navigation history via JavaScript.
