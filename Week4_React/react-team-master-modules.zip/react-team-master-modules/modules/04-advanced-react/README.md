# Advanced React

The purpose of this module is to explore some of the more advanced concepts in React, building on the foundation already established in previous modules.

## List of Topics

1. Higher-order components
2. Controlled and uncontrolled components
3. Refs
4. Context
5. Hooks

## Prerequisites & Learning Objectives

Before starting with the material in this module, associates should be familiar with:

- [React Fundamentals](../02-react-fundamentals)
- [Handling State](../03-handling-state)

After completing this module, associates should be able to:
