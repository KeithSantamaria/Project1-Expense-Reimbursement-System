# TypeScript with React

The purpose of this module is to describe the integration of TypeScript into a React application.

The entirety of the module is found in the [TypeScript with React](./typescript-with-react.md) topic.

## Prerequisites & Learning Objectives

Before starring with the material in this module, associates should be familiar with:

- [intro to react](../01-intro-to-react)
- TypeScript fundamentals

After completing this module, associates should be able to:

- see the benefits of working with TypeScript in a React application
- understand how to integrate TypeScript into components
