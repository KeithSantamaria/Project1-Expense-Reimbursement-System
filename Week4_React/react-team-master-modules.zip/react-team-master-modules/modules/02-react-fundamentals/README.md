# React Fundamentals

The purpose of this module is to introduce some of the fundamental concepts of React and help the associate understand the core concepts that one needs to know in order to use React.

Additional Resources in this module:

## List of Topics

1. [React Components](./components.md)
2. [JSX](./jsx.md)
3. [Rendering](./rendering.md)
4. [Lists and Keys](./lists-and-keys.md)
5. [Props and State](./props-and-state.md)
6. [Events](./events.md)
7. [Routing](./routing.md)

## Prerequisites & Learning Objectives

Before starting with the material in this module, associates should be familiar with:

- Front End JavaScript
- TypeScript
- HTML and CSS
- Node and npm

After completing this module, associates should be able to:

- Explain how components work in React
- Understand JSX, how it's used with React, and how it can be used for conditional rendering
- Render collections of elements, assigning keys appropriately
- Handle events and understand how synthetic events are used in React
- Understand the concept of props and state and how they are used within a component
