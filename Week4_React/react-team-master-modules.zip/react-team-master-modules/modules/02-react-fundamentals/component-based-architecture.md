# Component-based Architecture


Component-based architecture focuses on the decomposition of the design into individual functional or logical components that represent well-defined communication interfaces containing methods, events, and properties. It provides a higher level of abstraction and divides the problem into sub-problems, each associated with component partitions.

The primary objective of component-based architecture is to ensure component reusability. A component encapsulates functionality and behaviors of a software element into a reusable and self-deployable binary unit. Component-oriented software design has many advantages over the traditional object-oriented approaches such as −

	-Reduced time in market and the development cost by reusing existing components.

	-Increased reliability with the reuse of the existing components.
	
[Reference](https://www.tutorialspoint.com/software_architecture_design/component_based_architecture.htm)