# React Modules

1. [Intro to React](https://gitlab.com/revature_training/react-team/-/tree/master/modules/01-intro-to-react)

   - [Single Page Applications](https://gitlab.com/revature_training/react-team/-/blob/master/modules/01-intro-to-react/react-overview.md)
   - [Component-based architecture](https://gitlab.com/revature_training/react-team/-/blob/master/modules/01-intro-to-react/single-page-application.md)

2. [React Fundamentals](https://gitlab.com/revature_training/react-team/-/tree/master/modules/02-react-fundamentals)

   - Components and lifecycle
   - JSX
   - Data Binding
   - Props
   - Events
   - Conditional Rendering
   - Lists and Keys

3. [Handling State](https://gitlab.com/revature_training/react-team/-/tree/master/modules/03-handling-state)

   - Immutability
   - Lifting State Up
   - One-way data flow

4. [Advanced React](https://gitlab.com/revature_training/react-team/-/tree/master/modules/04-advanced-react)

   - Nested Components
   - Higher-order components
   - Controlled and uncontrolled components
   - Refs
   - Context
   - Hooks

5. [TypeScript with React](https://gitlab.com/revature_training/react-team/-/tree/initial-file-structure/modules/05-typescript-with-react)
6. [Axios Library](https://gitlab.com/revature_training/react-team/-/tree/initial-file-structure/modules/06-axios)
7. [Redux](https://gitlab.com/revature_training/react-team/-/tree/initial-file-structure/modules/07-redux)

   - Flux design pattern
   - Actions
   - Reducers
   - Store
   - Organizing state
   - Rxjs

8. [Testing with Jest and Enzyme](https://gitlab.com/revature_training/react-team/-/tree/initial-file-structure/modules/08-testing-with-jest-and-enzyme)
